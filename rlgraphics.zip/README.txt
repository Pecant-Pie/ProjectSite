Replace the file in your games directory (NOT steam!) with this one.
After making sure it has the exact same name, be sure to select
'lock' or 'read-only' to prevent Rocket League
from vetoing some of the settings it doesn't like. ;)
